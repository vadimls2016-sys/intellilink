package ru.intellilink

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.abs

/** Свайп влево/вправо по экрану. */
fun Modifier.swipe(onLeft: () -> Unit = {}, onRight: () -> Unit = {}, threshold: Float = 110f): Modifier =
    pointerInput(Unit) {
        var acc = 0f
        detectHorizontalDragGestures(
            onDragStart = { acc = 0f },
            onDragEnd = {
                if (acc <= -threshold) onLeft()
                if (acc >= threshold) onRight()
            },
            onHorizontalDrag = { _, d -> acc += d }
        )
    }

// ---------- форматирование ----------

private fun num(v: Float?, unit: String = "", digits: Int = 0): String {
    if (v == null) return "—"
    val s = if (digits == 0) v.toInt().toString() else String.format("%.${digits}f", v)
    return if (unit.isEmpty()) s else "$s $unit"
}

/** Значения климата и температур часто приходят в десятых долях. */
private fun scaled(v: Float?): Float? = when {
    v == null -> null
    abs(v) > 150f -> v / 10f
    else -> v
}

private fun press(v: Float?): String = when {
    v == null -> "—"
    v <= 12f -> num(v, "бар", 1)
    else -> num(v, "кПа")
}

private val WHEELS = listOf(
    "ПЛ" to arrayOf(arrayOf("tire", "fl"), arrayOf("tpms", "fl"), arrayOf("press", "fl"), arrayOf("wheel", "fl"), arrayOf("pressure", "fl"), arrayOf("tire", "1")),
    "ПП" to arrayOf(arrayOf("tire", "fr"), arrayOf("tpms", "fr"), arrayOf("press", "fr"), arrayOf("wheel", "fr"), arrayOf("pressure", "fr"), arrayOf("tire", "2")),
    "ЗЛ" to arrayOf(arrayOf("tire", "rl"), arrayOf("tpms", "rl"), arrayOf("press", "rl"), arrayOf("wheel", "rl"), arrayOf("pressure", "rl"), arrayOf("tire", "3")),
    "ЗП" to arrayOf(arrayOf("tire", "rr"), arrayOf("tpms", "rr"), arrayOf("press", "rr"), arrayOf("wheel", "rr"), arrayOf("pressure", "rr"), arrayOf("tire", "4"))
)

// ---------- экран автомобиля ----------

@Composable
fun CarScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    DisposableEffect(Unit) {
        Can.start(ctx)
        onDispose { Can.stop() }
    }
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().swipe(onRight = onBack).padding(horizontal = 20.dp, vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            T("АВТОМОБИЛЬ", 14, color = C.dim, spacing = 2f)
            Spacer(Modifier.width(20.dp))
            for ((i, name) in listOf("Климат", "Автомобиль").withIndex()) {
                val active = i == tab
                val shape = RoundedCornerShape(10.dp)
                Box(
                    Modifier.height(40.dp).padding(end = 8.dp).clip(shape)
                        .background(if (active) C.card else Color.Transparent)
                        .border(1.dp, if (active) C.line else Color.Transparent, shape)
                        .tap { tab = i }.padding(horizontal = 18.dp),
                    contentAlignment = Alignment.Center
                ) { T(name, 16, color = if (active) C.text else C.dim, weight = FontWeight.SemiBold) }
            }
            Spacer(Modifier.weight(1f))
            T(Can.status.value, 13, color = C.dim)
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (tab == 0) ClimateTab() else CarTab()
        }
    }
}

@Composable
private fun ClimateTab() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Metric("ТЕМПЕРАТУРА В САЛОНЕ",
                num(scaled(Can.n(arrayOf("interior", "temp"), arrayOf("cabin", "temp"), arrayOf("inside", "temp"), arrayOf("in", "temp"))), "°C", 1),
                Ic.LOGO, Modifier.weight(1f))
            Metric("ЗАДАННАЯ ТЕМПЕРАТУРА",
                num(scaled(Can.n(arrayOf("set", "temp"), arrayOf("target", "temp"), arrayOf("desired", "temp"), arrayOf("temp", "set"))), "°C", 1),
                Ic.SETTINGS, Modifier.weight(1f))
            Metric("ВЕНТИЛЯТОР",
                num(Can.n(arrayOf("fan", "level"), arrayOf("fan", "speed"), arrayOf("blower"), arrayOf("wind", "speed"), arrayOf("fan"))),
                Ic.VOLUME, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Metric("ОБДУВ",
                Can.text(arrayOf("blow"), arrayOf("air", "mode"), arrayOf("vent", "mode"), arrayOf("airflow"), arrayOf("mode")) ?: "—",
                Ic.NAV, Modifier.weight(1f))
            Metric("КОНДИЦИОНЕР",
                onOff(Can.on(arrayOf("ac"), arrayOf("aircon"), arrayOf("compressor"), arrayOf("a/c"))),
                Ic.LOGO, Modifier.weight(1f))
            Metric("РЕЦИРКУЛЯЦИЯ",
                onOff(Can.on(arrayOf("recirc"), arrayOf("circul"), arrayOf("recir"))),
                Ic.CAR, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Metric("ПОДОГРЕВ СИДЕНИЙ",
                num(Can.n(arrayOf("seat", "heat"), arrayOf("heated", "seat"), arrayOf("seat", "level"))),
                Ic.CAR, Modifier.weight(1f))
            Metric("ТЕМПЕРАТУРА СНАРУЖИ",
                num(scaled(Can.n(arrayOf("outside", "temp"), arrayOf("out", "temp"), arrayOf("ambient"), arrayOf("ext", "temp"))), "°C", 1),
                Ic.LOGO, Modifier.weight(1f))
            Spacer(Modifier.weight(1f))
        }
        RawList()
    }
}

@Composable
private fun CarTab() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Metric("ДВИГАТЕЛЬ",
                num(scaled(Can.n(arrayOf("coolant"), arrayOf("engine", "temp"), arrayOf("eng", "temp"), arrayOf("water", "temp"))), "°C", 1),
                Ic.CAR, Modifier.weight(1f))
            Metric("МАСЛО",
                num(scaled(Can.n(arrayOf("oil", "temp"))), "°C", 1),
                Ic.CAR, Modifier.weight(1f))
            Metric("ДАВЛЕНИЕ МАСЛА",
                press(Can.n(arrayOf("oil", "press"), arrayOf("oil", "pressure"))),
                Ic.CAR, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Metric("ТОПЛИВО",
                num(Can.n(arrayOf("fuel", "level"), arrayOf("fuel", "percent"), arrayOf("fuel", "pct"), arrayOf("fuel")), "%"),
                Ic.CAR, Modifier.weight(1f))
            Metric("НАПРЯЖЕНИЕ",
                num(scaled(Can.n(arrayOf("volt"), arrayOf("battery"), arrayOf("batt"))), "В", 1),
                Ic.CAR, Modifier.weight(1f))
            Metric("ЗАПАС ХОДА",
                num(Can.n(arrayOf("range"), arrayOf("remain", "fuel"), arrayOf("dte"))),
                Ic.NAV, Modifier.weight(1f))
        }
        T("ДАВЛЕНИЕ В ШИНАХ", 13, color = C.dim, spacing = 2f)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            for ((label, groups) in WHEELS) {
                Metric(label, press(Can.n(*groups)), Ic.CAR, Modifier.weight(1f))
            }
        }
        RawList()
    }
}

private fun onOff(b: Boolean?): String = when (b) {
    null -> "—"
    true -> "ВКЛ"
    else -> "ВЫКЛ"
}

@Composable
private fun Metric(label: String, value: String, icon: String, modifier: Modifier) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.height(124.dp).clip(shape).background(C.card).border(1.dp, C.line, shape).padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            LineIcon(icon, 20.dp, C.dim)
            Spacer(Modifier.width(8.dp))
            T(label, 12, color = C.dim, spacing = 1.5f)
        }
        T(value, 30, weight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun RawList() {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(C.card).border(1.dp, C.line, shape).padding(16.dp)) {
        Row(Modifier.fillMaxWidth().tap { open = !open }, verticalAlignment = Alignment.CenterVertically) {
            T("Сырые данные CAN", 14, color = C.dim, spacing = 1.5f)
            Spacer(Modifier.weight(1f))
            T(if (open) "СВЕРНУТЬ" else "РАЗВЕРНУТЬ", 13, color = C.redText, weight = FontWeight.SemiBold)
        }
        if (open) {
            Spacer(Modifier.height(12.dp))
            T(Can.status.value + " · значений: " + Can.count(), 13, color = C.dim)
            if (Can.count() == 0) {
                Spacer(Modifier.height(8.dp))
                T("Магнитола не отдала ни одного значения. Пришлите этот экран — по именам методов подберём нужные поля.", 13, color = C.dim)
            }
            for ((k, v) in Can.values.entries.sortedBy { it.key }) {
                if (v.isBlank()) continue
                Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    T(k, 13, color = C.dim, modifier = Modifier.weight(1f), maxLines = 1)
                    Spacer(Modifier.width(12.dp))
                    T(v, 13, maxLines = 1)
                }
            }
        }
    }
}
