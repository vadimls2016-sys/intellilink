package ru.intellilink

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import java.lang.reflect.Method
import java.util.concurrent.ConcurrentHashMap

/**
 * Чтение данных CAN-шины магнитолы.
 * Службы магнитолы отдают данные только через AIDL, описание интерфейса лежит в её же APK,
 * поэтому интерфейс подгружается рефлексией из установленного пакета.
 * Вызываются только методы без аргументов (get*/is*/read*/query*), ничего в машину не отправляется.
 */
object Can {
    val values = mutableStateMapOf<String, String>()
    val status = mutableStateOf("поиск службы CAN…")
    val found = mutableStateOf(0)

    private val methods = ConcurrentHashMap<String, Method>()
    @Volatile private var proxy: Any? = null
    private val handler = Handler(Looper.getMainLooper())

    private val targets = listOf(
        "com.kyhero.car.myhost" to "com.kyhero.car.myhost.Canset.CanbusService",
        "com.kyhero.car.myhost" to "com.kyhero.car.myhost.Canset.AidlToOutDataService",
        "com.kyhero.car.myhost" to "com.kyhero.car.myhost.Canset.AidlToOutData6115Service"
    )

    private val tick = object : Runnable {
        override fun run() {
            poll()
            handler.postDelayed(this, 700)
        }
    }

    fun start(c: Context) {
        val app = c.applicationContext
        if (proxy == null) targets.forEach { (pkg, cls) -> bind(app, pkg, cls) }
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    fun stop() = handler.removeCallbacks(tick)

    private fun bind(c: Context, pkg: String, cls: String) {
        val short = cls.substringAfterLast('.')
        val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, b: IBinder?) {
                if (b == null) return
                status.value = "подключено: $short"
                Thread { prepare(c, pkg, b, short) }.start()
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                status.value = "служба $short отключилась"
            }
        }
        try {
            val ok = c.bindService(Intent().setClassName(pkg, cls), conn, Context.BIND_AUTO_CREATE)
            if (!ok) Diag.add("CAN: $short не принимает подключение")
        } catch (e: Exception) {
            Diag.add("CAN: $short — ${e.message}")
        }
    }

    private fun prepare(c: Context, pkg: String, b: IBinder, short: String) {
        try {
            val path = c.packageManager.getApplicationInfo(pkg, 0).sourceDir
            val cl = dalvik.system.PathClassLoader(path, null, c.classLoader)
            val desc = try { b.interfaceDescriptor } catch (e: Throwable) { null }
            val candidates = listOfNotNull(desc, "com.xygala.buslibrary.IBusService").distinct()
            var ok = false
            for (descName in candidates) {
                try {
                    val iface = cl.loadClass(descName)
                    val stub = cl.loadClass("$descName\$Stub")
                    val p = stub.getMethod("asInterface", IBinder::class.java).invoke(null, b)
                    val local = mutableMapOf<String, Method>()
                    for (m in iface.declaredMethods) {
                        if (m.parameterCount != 0) continue
                        val n = m.name.lowercase()
                        val getter = n.startsWith("get") || n.startsWith("is") ||
                            n.startsWith("read") || n.startsWith("query")
                        if (getter) local[m.name] = m
                    }
                    methods.clear(); methods.putAll(local)
                    proxy = p
                    found.value = local.size
                    status.value = "подключено: $short"
                    Diag.addUi("CAN: ${descName.substringAfterLast('.')} — доступно методов ${local.size}")
                    ok = true
                    break
                } catch (e: Throwable) {
                    Diag.addUi("CAN: ${descName.substringAfterLast('.')} — ${e.javaClass.simpleName}")
                }
            }
            if (!ok) Diag.addUi("CAN: интерфейс $short не распознан")
        } catch (e: Throwable) {
            Diag.addUi("CAN: ${e.javaClass.simpleName} ${e.message}")
        }
    }

    private fun poll() {
        val p = proxy ?: return
        for ((name, m) in methods) {
            val v = try { Diag.fmt(m.invoke(p)) } catch (e: Throwable) { continue }
            if (values[name] != v) values[name] = v
        }
    }

    // ---------- выбор значений по смыслу имени метода ----------

    /** Первое значение, в имени метода которого встречаются все слова одной из групп. */
    fun text(vararg groups: Array<String>): String? {
        for (g in groups) {
            for ((k, v) in values) {
                val key = k.lowercase()
                if (g.all { key.contains(it) } && v.isNotBlank()) return v
            }
        }
        return null
    }

    fun n(vararg groups: Array<String>): Float? {
        val t = text(*groups) ?: return null
        return Regex("-?\\d+([.,]\\d+)?").find(t)?.value?.replace(',', '.')?.toFloatOrNull()
    }

    fun on(vararg groups: Array<String>): Boolean? {
        val t = text(*groups)?.lowercase() ?: return null
        return t.contains("true") || t == "1" || t.contains("on") || t.contains("вкл")
    }

    fun count() = values.size
}
