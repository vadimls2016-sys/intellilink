package ru.intellilink

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class NP(
    val access: Boolean = true,
    val controller: MediaController? = null,
    val title: String? = null,
    val artist: String? = null,
    val playing: Boolean = false,
    val art: Bitmap? = null,
    val source: String = ""
)

object Player {
    fun read(ctx: Context): NP {
        return try {
            val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
            val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                ?: list.firstOrNull()
            if (c == null) NP() else {
                val md = c.metadata
                val pm = ctx.packageManager
                val label = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(c.packageName, 0)).toString()
                } catch (e: Exception) { c.packageName }
                NP(
                    true, c,
                    md?.getString(MediaMetadata.METADATA_KEY_TITLE),
                    md?.getString(MediaMetadata.METADATA_KEY_ARTIST),
                    c.playbackState?.state == PlaybackState.STATE_PLAYING,
                    md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART),
                    label
                )
            }
        } catch (e: SecurityException) {
            NP(access = false)
        } catch (e: Exception) {
            NP()
        }
    }

    fun next(ctx: Context, np: NP) {
        val t = np.controller?.transportControls
        if (t != null) t.skipToNext() else ctx.mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun prev(ctx: Context, np: NP) {
        val t = np.controller?.transportControls
        if (t != null) t.skipToPrevious() else ctx.mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    fun toggle(ctx: Context, np: NP) {
        val t = np.controller?.transportControls
        if (t != null) { if (np.playing) t.pause() else t.play() }
        else ctx.mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
    }
}

object Margins {
    var right by mutableStateOf(40)
    var bottom by mutableStateOf(16)
    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("ui", 0)
        right = p.getInt("mr", 40)
        bottom = p.getInt("mb", 16)
    }
    fun save(ctx: Context) {
        ctx.getSharedPreferences("ui", 0).edit().putInt("mr", right).putInt("mb", bottom).apply()
    }
}
