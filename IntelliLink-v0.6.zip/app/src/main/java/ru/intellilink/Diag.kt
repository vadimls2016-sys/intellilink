package ru.intellilink

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.session.MediaSessionManager
import android.os.Build
import androidx.compose.runtime.mutableStateListOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Diag {
    val log = mutableStateListOf<String>()

    private val actions = listOf(
        "com.android.music.metachanged",
        "com.android.music.playstatechanged",
        "com.android.music.playbackcomplete",
        "com.android.music.queuechanged",
        "com.htc.music.metachanged",
        "com.miui.player.metachanged",
        "com.spotify.music.metadatachanged",
        "com.spotify.music.playbackstatechanged",
        "fm.last.android.metachanged",
        "net.jjc1138.android.scrobbler.metachanged",
        "android.bluetooth.a2dp.profile.action.PLAYING_STATE_CHANGED",
        "android.bluetooth.a2dp.profile.action.CONNECTION_STATE_CHANGED",
        "android.bluetooth.a2dp-sink.profile.action.PLAYING_STATE_CHANGED",
        "android.bluetooth.a2dp-sink.profile.action.CONNECTION_STATE_CHANGED",
        "android.bluetooth.device.action.ACL_CONNECTED",
        "android.bluetooth.device.action.ACL_DISCONNECTED",
        "android.bluetooth.avrcp-controller.profile.action.CONNECTION_STATE_CHANGED",
        "android.bluetooth.adapter.action.STATE_CHANGED"
    )

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val extras = intent.extras?.keySet()?.joinToString(", ") { k ->
                val v = intent.extras?.get(k).toString()
                "$k=" + (if (v.length > 50) v.take(50) + "…" else v)
            } ?: ""
            add("${intent.action}  $extras")
        }
    }

    fun add(s: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        log.add(0, "$t $s")
        while (log.size > 40) log.removeAt(log.size - 1)
    }

    fun start(ctx: Context) {
        val f = IntentFilter()
        actions.forEach { f.addAction(it) }
        try {
            if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
            else ctx.registerReceiver(receiver, f)
        } catch (e: Exception) {
            add("Ошибка регистрации: ${e.message}")
        }
    }

    fun stop(ctx: Context) {
        try { ctx.unregisterReceiver(receiver) } catch (e: Exception) { }
    }

    fun sessions(ctx: Context): List<String> {
        return try {
            val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
            if (list.isEmpty()) listOf("Активных медиа-сессий нет")
            else list.map { c ->
                val md = c.metadata
                val title = md?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
                val artist = md?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST)
                "${c.packageName} | состояние=${c.playbackState?.state} | $title — $artist | длит=${md?.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION)} | обложка=${md?.getBitmap(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART) != null} uri=${md?.getString(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART_URI)}"
            }
        } catch (e: SecurityException) {
            listOf("Нет доступа к уведомлениям (включите его кнопкой выше)")
        } catch (e: Exception) {
            listOf("Ошибка: ${e.message}")
        }
    }

    private val keys = listOf("bt", "blue", "music", "media", "radio", "audio", "syu", "raise", "fyt", "zxw", "mcu", "canbus", "carplay", "launcher", "player", "phone", "factory", "setting", "sound", "eq", "tmedia", "acloud", "autochips")

    fun apps(ctx: Context): List<String> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0)
            .filter { a -> keys.any { a.packageName.lowercase().contains(it) } }
            .map { "${pm.getApplicationLabel(it)} — ${it.packageName}" }
            .sorted()
    }

    fun vendorPackages(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0)
            .filter { a ->
                val n = a.packageName
                n != ctx.packageName && !n.startsWith("com.android.") && !n.startsWith("com.google.") &&
                    !n.startsWith("com.mediatek.") && !n.startsWith("android") && !n.startsWith("org.chromium")
            }
            .map { pm.getApplicationLabel(it).toString() to it.packageName }
            .sortedBy { it.second }
    }

    fun manifest(ctx: Context, pkg: String): List<String> {
        val out = mutableListOf<String>()
        try {
            val res = ctx.packageManager.getResourcesForApplication(pkg)
            val p = res.assets.openXmlResourceParser("AndroidManifest.xml")
            val ns = "http://schemas.android.com/apk/res/android"
            val tags = listOf("service", "receiver", "provider", "activity")
            var comp: String? = null
            val acts = mutableListOf<String>()
            var ev = p.eventType
            while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                    if (p.name in tags) {
                        val exp = if (p.getAttributeValue(ns, "exported") == "true") " +exp" else ""
                        comp = p.name.take(1).uppercase() + " " + (p.getAttributeValue(ns, "name") ?: "?") + exp
                        acts.clear()
                    } else if (p.name == "action" && comp != null) {
                        acts.add(p.getAttributeValue(ns, "name") ?: "?")
                    }
                } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG && p.name in tags && comp != null) {
                    val isAct = comp!!.startsWith("A")
                    if (!(isAct && acts.isEmpty())) out.add(comp + if (acts.isEmpty()) "" else "  [" + acts.joinToString(", ") + "]")
                    comp = null
                }
                ev = p.next()
            }
        } catch (e: Exception) {
            out.add("Ошибка: ${e.message}")
        }
        return out
    }
}
