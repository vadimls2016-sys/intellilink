package ru.intellilink

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.audiofx.Equalizer
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

// ---------- общие кнопки ----------

@Composable
fun Chip(label: String, active: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier.height(56.dp).clip(shape).background(if (active) C.red else C.card)
            .border(1.dp, if (active) C.red else C.line, shape).tap(onClick).padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) { T(label, 18, weight = FontWeight.SemiBold) }
}

// ---------- яркость ----------

fun readBrightnessPct(ctx: Context): Int =
    Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) * 100 / 255

fun writeBrightnessPct(ctx: Context, pct: Int) {
    val v = (pct * 255 / 100).coerceIn(1, 255)
    try {
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
    } catch (e: Exception) { }
}

@Composable
fun BrightScreen() {
    val ctx = LocalContext.current
    val can by produceState(Settings.System.canWrite(ctx)) {
        while (true) { value = Settings.System.canWrite(ctx); delay(1000) }
    }
    var pct by remember { mutableStateOf(readBrightnessPct(ctx)) }
    fun apply(p: Int) { pct = p.coerceIn(5, 100); writeBrightnessPct(ctx, pct) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        T("ЯРКОСТЬ ЭКРАНА", 14, color = C.dim, spacing = 2f)
        if (!can) {
            T("Нужно разрешить приложению менять системные настройки (один раз).", 20)
            Chip("Разрешить", active = true) {
                ctx.open(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            }
        } else {
            T("$pct%", 56, weight = FontWeight.Bold)
            Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(C.btn)) {
                Box(Modifier.fillMaxWidth(pct / 100f).fillMaxHeight().background(C.red))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                StepBtn("−") { apply(pct - 10) }
                StepBtn("+") { apply(pct + 10) }
                Spacer(Modifier.width(12.dp))
                for (p in listOf(10, 30, 60, 100)) Chip("$p%", active = pct == p) { apply(p) }
            }
            T(
                "Если яркость не меняется, значит подсветкой экрана управляет сама магнитола. Тогда напишите мне, найду другой способ.",
                15, color = C.dim
            )
        }
    }
}

// ---------- эквалайзер ----------

object Eq {
    private var eq: Equalizer? = null
    var status by mutableStateOf("")
    var enabled by mutableStateOf(true)
    val levels = mutableStateListOf<Int>()
    var minL = -1500
    var maxL = 1500
    var freqs: List<Int> = emptyList()

    fun init(ctx: Context) {
        if (eq != null) return
        try {
            val e = Equalizer(0, 0)
            eq = e
            val n = e.numberOfBands.toInt()
            minL = e.bandLevelRange[0].toInt()
            maxL = e.bandLevelRange[1].toInt()
            freqs = (0 until n).map { e.getCenterFreq(it.toShort()) / 1000 }
            val p = ctx.getSharedPreferences("eq", 0)
            levels.clear()
            for (i in 0 until n) {
                val l = p.getInt("b$i", 0).coerceIn(minL, maxL)
                levels.add(l)
                e.setBandLevel(i.toShort(), l.toShort())
            }
            enabled = p.getBoolean("on", true)
            e.setEnabled(enabled)
            status = "Эквалайзер Android подключён, полос: $n"
        } catch (ex: Exception) {
            status = "Эквалайзер Android недоступен: ${ex.message}"
        }
    }

    private fun save(ctx: Context) {
        val ed = ctx.getSharedPreferences("eq", 0).edit()
        levels.forEachIndexed { i, l -> ed.putInt("b$i", l) }
        ed.putBoolean("on", enabled).apply()
    }

    fun set(ctx: Context, i: Int, level: Int) {
        val l = level.coerceIn(minL, maxL)
        try { eq?.setBandLevel(i.toShort(), l.toShort()) } catch (e: Exception) { }
        if (i < levels.size) levels[i] = l
        save(ctx)
    }

    fun toggle(ctx: Context) {
        enabled = !enabled
        try { eq?.setEnabled(enabled) } catch (e: Exception) { }
        save(ctx)
    }

    fun preset(ctx: Context, db: List<Int>) {
        val n = levels.size
        for (i in 0 until n) {
            val pos = if (n == 1) 0f else i * (db.size - 1f) / (n - 1f)
            val a = pos.toInt().coerceAtMost(db.size - 1)
            val b = (a + 1).coerceAtMost(db.size - 1)
            val v = db[a] + (db[b] - db[a]) * (pos - a)
            set(ctx, i, (v * 100).toInt())
        }
    }
}

val EQ_PRESETS = listOf(
    "Плоский" to listOf(0, 0, 0, 0, 0),
    "Бас" to listOf(6, 4, 1, 0, 0),
    "Вокал" to listOf(-2, 0, 4, 3, 1),
    "Рок" to listOf(4, 2, -1, 3, 4),
    "Поп" to listOf(-1, 2, 4, 2, -1),
    "Джаз" to listOf(3, 2, -2, 2, 4),
    "Классика" to listOf(3, 2, -1, 2, 3)
)

fun fmtFreq(hz: Int): String = if (hz >= 1000) {
    val k = hz / 1000f
    (if (k == k.toInt().toFloat()) "${k.toInt()}" else String.format(java.util.Locale.US, "%.1f", k)) + " кГц"
} else "$hz Гц"

@Composable
fun VBand(level: Int, min: Int, max: Int, label: String, modifier: Modifier, onSet: (Int) -> Unit) {
    var h by remember { mutableStateOf(1f) }
    fun fromY(y: Float) {
        val frac = 1f - (y / h).coerceIn(0f, 1f)
        val l = min + frac * (max - min)
        onSet((Math.round(l / 100f) * 100))
    }
    val frac = ((level - min).toFloat() / (max - min)).coerceIn(0f, 1f)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        T((if (level > 0) "+" else "") + "${level / 100} дБ", 16, weight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.fillMaxWidth().height(200.dp)
                .onSizeChanged { h = it.height.toFloat() }
                .pointerInput(Unit) { detectTapGestures { fromY(it.y) } }
                .pointerInput(Unit) {
                    detectDragGestures(onDragStart = { fromY(it.y) }) { c, _ -> c.consume(); fromY(c.position.y) }
                },
            contentAlignment = Alignment.BottomCenter
        ) {
            Box(Modifier.width(14.dp).fillMaxHeight().clip(RoundedCornerShape(7.dp)).background(C.btn))
            Box(Modifier.width(14.dp).fillMaxHeight(frac).clip(RoundedCornerShape(7.dp)).background(C.red))
        }
        Spacer(Modifier.height(8.dp))
        T(label, 14, color = C.dim, align = TextAlign.Center)
    }
}

@Composable
fun EqScreen(onApps: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            T("ЭКВАЛАЙЗЕР", 14, color = C.dim, spacing = 2f)
            Chip(if (Eq.enabled) "Включён" else "Выключен", active = Eq.enabled) { Eq.toggle(ctx) }
        }
        if (Eq.levels.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Eq.levels.forEachIndexed { i, l ->
                    VBand(l, Eq.minL, Eq.maxL, fmtFreq(Eq.freqs.getOrElse(i) { 0 }), Modifier.weight(1f)) { Eq.set(ctx, i, it) }
                }
            }
            for (row in EQ_PRESETS.chunked(4)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    for ((name, db) in row) Chip(name) { Eq.preset(ctx, db) }
                }
            }
        }
        if (Eq.levels.isEmpty()) {
            T("Эквалайзер Android на этой магнитоле не работает: звук идёт через собственный аудиомодуль. Штатный эквалайзер магнитолы называется «Звуковой эффект».", 18)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Chip("Открыть «Звуковой эффект»", active = true) { ctx.openPkg("com.xy.tda7729") }
                Chip("Все приложения") { onApps() }
            }
        }
        T(Eq.status, 14, color = C.dim)
        T(
            "Если звук при движении ползунков не меняется, эквалайзер Android на этой магнитоле не действует. Тогда используйте штатные настройки звука.",
            14, color = C.dim
        )
    }
}

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    return String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
}

// ---------- громкость ----------

@Composable
fun VolBar() {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val max = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var v by remember { mutableStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC)) }
    LaunchedEffect(Unit) {
        while (true) { v = am.getStreamVolume(AudioManager.STREAM_MUSIC); delay(1500) }
    }
    fun set(n: Int) {
        val x = n.coerceIn(0, max)
        v = x
        try { am.setStreamVolume(AudioManager.STREAM_MUSIC, x, 0) } catch (e: Exception) { }
    }
    var w by remember { mutableStateOf(1f) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        LineIcon(Ic.VOLUME, 28.dp, C.dim)
        StepBtn("−") { set(v - 1) }
        Box(
            Modifier.weight(1f).height(40.dp)
                .onSizeChanged { w = it.width.toFloat() }
                .pointerInput(Unit) { detectTapGestures { set(Math.round(it.x / w * max)) } }
                .pointerInput(Unit) {
                    detectDragGestures(onDragStart = { set(Math.round(it.x / w * max)) }) { c, _ ->
                        c.consume(); set(Math.round(c.position.x / w * max))
                    }
                },
            contentAlignment = Alignment.CenterStart
        ) {
            Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(C.btn))
            Box(Modifier.fillMaxWidth(v.toFloat() / max).height(10.dp).clip(RoundedCornerShape(5.dp)).background(C.red))
        }
        StepBtn("+") { set(v + 1) }
        T("$v", 16, color = C.dim, modifier = Modifier.width(32.dp))
    }
}

// ---------- все приложения ----------

class AppItem(val label: String, val pkg: String, val cls: String, val icon: ImageBitmap)

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { ri ->
            val d = ri.loadIcon(pm)
            val bmp = android.graphics.Bitmap.createBitmap(96, 96, android.graphics.Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 96, 96)
            d.draw(android.graphics.Canvas(bmp))
            AppItem(ri.loadLabel(pm).toString(), ri.activityInfo.packageName, ri.activityInfo.name, bmp.asImageBitmap())
        }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    val apps = remember { loadApps(ctx) }
    val shape = RoundedCornerShape(12.dp)
    LazyVerticalGrid(
        GridCells.Adaptive(130.dp), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(apps) { a ->
            Column(
                Modifier.clip(shape).background(C.card).border(1.dp, C.line, shape).tap {
                    ctx.open(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(a.pkg, a.cls))
                }.padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(a.icon, null, Modifier.size(56.dp))
                Spacer(Modifier.height(6.dp))
                T(a.label, 14, align = TextAlign.Center, maxLines = 2)
                T(a.pkg, 10, color = C.dim, align = TextAlign.Center, maxLines = 1)
            }
        }
    }
}

// ---------- диагностика CAN ----------

@Composable
fun CanDiagScreen() {
    val ctx = LocalContext.current
    val pkgs = remember { Diag.vendorPackages(ctx) }
    var sel by remember { mutableStateOf<String?>(null) }
    var dump by remember { mutableStateOf(listOf<String>()) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        T("ДИАГНОСТИКА CAN: нажмите на пакет, чтобы увидеть его службы и сообщения", 14, color = C.dim)
        if (sel != null) {
            T(sel!!, 16, weight = FontWeight.SemiBold, color = C.redText)
            if (dump.isEmpty()) T("пусто", 13, color = C.dim)
            dump.forEach { T(it, 12, color = C.dim) }
            Spacer(Modifier.height(10.dp))
        }
        T("Пакеты магнитолы:", 16, weight = FontWeight.SemiBold)
        pkgs.forEach { (label, pkg) ->
            T("$label — $pkg", 14, modifier = Modifier.tap { sel = pkg; dump = Diag.manifest(ctx, pkg) }.padding(vertical = 6.dp))
        }
    }
}
