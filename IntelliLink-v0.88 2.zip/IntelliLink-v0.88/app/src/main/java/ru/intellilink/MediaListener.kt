package ru.intellilink

import android.service.notification.NotificationListenerService

// Пустая служба: нужна только чтобы получить доступ к активным медиа-сессиям Android.
class MediaListener : NotificationListenerService()
