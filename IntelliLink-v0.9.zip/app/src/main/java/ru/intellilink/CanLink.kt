package ru.intellilink

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Parcel
import android.os.Parcelable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import java.lang.reflect.Proxy
import java.util.concurrent.ConcurrentHashMap

// Только слушаем данные CAN у штатного приложения магнитолы. Ничего в автомобиль не отправляем.
object CanLink {
    private const val PKG = "com.kyhero.car.myhost"
    val values = mutableStateMapOf<String, String>()
    val methods = mutableStateListOf<String>()
    private val main = Handler(Looper.getMainLooper())
    private val keep = ArrayList<Any>()
    private val last = ConcurrentHashMap<String, String>()
    private var started = false

    private val targets = listOf(
        Triple("Data", "com.kyhero.car.myhost.Canset.AidlToOutDataService", "com.kyhero.car.myhost.action"),
        Triple("Data6115", "com.kyhero.car.myhost.Canset.AidlToOutData6115Service", "com.kyhero.car.myhost.action1"),
        Triple("Bus", "com.kyhero.car.myhost.Canset.CanbusService", "com.xygala.buslibrary.IBusService")
    )

    fun start(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        for (t in targets) {
            val short = t.first
            val conn = object : ServiceConnection {
                override fun onServiceConnected(n: ComponentName, b: IBinder) {
                    Thread { attach(app, short, b) }.start()
                }
                override fun onServiceDisconnected(n: ComponentName) {
                    Diag.addUi("CAN $short: служба отключилась")
                }
            }
            synchronized(keep) { keep.add(conn) }
            try {
                app.bindService(Intent(t.third).setClassName(PKG, t.second), conn, Context.BIND_AUTO_CREATE)
            } catch (e: Exception) {
                Diag.addUi("CAN $short: ${e.message}")
            }
        }
    }

    private fun attach(ctx: Context, short: String, b: IBinder) {
        try {
            val desc: String = try { b.interfaceDescriptor ?: "" } catch (e: Exception) { "" }
            val path = ctx.packageManager.getApplicationInfo(PKG, 0).sourceDir
            val cl = dalvik.system.PathClassLoader(path, null, ctx.classLoader)
            val iface = cl.loadClass(desc)
            val stub = cl.loadClass(desc + "\$Stub")
            val proxy = stub.getMethod("asInterface", IBinder::class.java).invoke(null, b)
            val reg = iface.declaredMethods.firstOrNull { it.name == "registerListener" || it.name == "registerCallback" }
            if (reg == null) {
                Diag.addUi("CAN $short: нет метода подписки")
                return
            }
            val params = reg.parameterTypes
            val args = arrayOfNulls<Any>(params.size)
            for (i in params.indices) args[i] = makeListener(params[i], short)
            reg.invoke(proxy, *args)
            Diag.addUi("CAN $short: подписка оформлена, слушателей: ${params.size}")
        } catch (e: Throwable) {
            val c = e.cause ?: e
            Diag.addUi("CAN $short: ошибка подписки ${c.javaClass.simpleName} ${c.message}")
        }
    }

    private fun makeListener(cls: Class<*>, svc: String): Any {
        val loader = cls.classLoader
        val stubCls: Class<*>? = try { loader.loadClass(cls.name + "\$Stub") } catch (e: Throwable) { null }
        var desc = cls.name
        if (stubCls != null) {
            try {
                val f = stubCls.getDeclaredField("DESCRIPTOR")
                f.isAccessible = true
                desc = f.get(null) as String
            } catch (e: Throwable) { }
        }
        val finalDesc = desc
        val ifcName = cls.simpleName
        val codes = HashMap<Int, Method>()
        val sigs = ArrayList<String>()
        for (m in cls.declaredMethods) {
            sigs.add(svc + " " + ifcName + "." + m.name + "(" + m.parameterTypes.joinToString { it.simpleName } + ")")
            if (stubCls != null) {
                try {
                    val f = stubCls.getDeclaredField("TRANSACTION_" + m.name)
                    f.isAccessible = true
                    codes[f.getInt(null)] = m
                } catch (e: Throwable) { }
            }
        }
        main.post { methods.addAll(sigs) }

        val binder = object : Binder() {
            init {
                attachInterface(null, finalDesc)
            }

            override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
                val m = codes[code] ?: return super.onTransact(code, data, reply, flags)
                try {
                    data.enforceInterface(finalDesc)
                    val vals = ArrayList<Any?>()
                    for (t in m.parameterTypes) vals.add(readArg(data, t))
                    handle(svc, ifcName, m.name, vals)
                } catch (e: Throwable) {
                    if (last.put("err:" + ifcName + "." + m.name, "1") == null) {
                        Diag.addUi("CAN: не разобран вызов $ifcName.${m.name}: ${e.message}")
                    }
                }
                if (reply != null) {
                    reply.writeNoException()
                    val rt = m.returnType
                    if (rt == java.lang.Integer.TYPE || rt == java.lang.Boolean.TYPE) reply.writeInt(0)
                    else if (rt == java.lang.Float.TYPE) reply.writeFloat(0f)
                }
                return true
            }
        }

        val handler = InvocationHandler { _, method, _ ->
            when (method.name) {
                "asBinder" -> binder
                "hashCode" -> System.identityHashCode(binder)
                "equals" -> false
                "toString" -> "CanListener"
                else -> null
            }
        }
        val obj = Proxy.newProxyInstance(loader, arrayOf(cls), handler)
        synchronized(keep) {
            keep.add(binder)
            keep.add(obj)
        }
        return obj
    }

    private fun readArg(d: Parcel, t: Class<*>): Any? {
        if (t == java.lang.Integer.TYPE) return d.readInt()
        if (t == java.lang.Float.TYPE) return d.readFloat()
        if (t == java.lang.Double.TYPE) return d.readDouble()
        if (t == java.lang.Long.TYPE) return d.readLong()
        if (t == java.lang.Boolean.TYPE) return d.readInt() != 0
        if (t == java.lang.Byte.TYPE) return d.readByte()
        if (t == String::class.java) return d.readString()
        if (t == IntArray::class.java) return d.createIntArray()
        if (t == ByteArray::class.java) return d.createByteArray()
        if (t == FloatArray::class.java) return d.createFloatArray()
        if (t == DoubleArray::class.java) return d.createDoubleArray()
        if (t == LongArray::class.java) return d.createLongArray()
        if (t == BooleanArray::class.java) return d.createBooleanArray()
        if (t == Array<String>::class.java) return d.createStringArray()
        val creator = try { t.getField("CREATOR").get(null) } catch (e: Throwable) { null }
        if (creator is Parcelable.Creator<*>) {
            return if (d.readInt() != 0) creator.createFromParcel(d) else null
        }
        throw IllegalStateException("тип " + t.name)
    }

    private fun show(o: Any?, depth: Int = 0): String {
        if (o == null) return "null"
        return when (o) {
            is ByteArray -> o.take(32).joinToString(" ") { String.format("%02X", it) } + (if (o.size > 32) "…" else "")
            is IntArray -> o.joinToString(",")
            is FloatArray -> o.joinToString(",")
            is DoubleArray -> o.joinToString(",")
            is LongArray -> o.joinToString(",")
            is BooleanArray -> o.joinToString(",")
            is Array<*> -> o.joinToString(",") { show(it, depth + 1) }
            is String, is Number, is Boolean -> o.toString()
            else -> {
                if (depth >= 2) {
                    o.toString().take(40)
                } else {
                    val parts = ArrayList<String>()
                    for (f in o.javaClass.declaredFields) {
                        if (Modifier.isStatic(f.modifiers)) continue
                        try {
                            f.isAccessible = true
                            parts.add(f.name + "=" + show(f.get(o), depth + 1))
                        } catch (e: Throwable) { }
                    }
                    if (parts.isEmpty()) o.toString().take(60) else "{" + parts.joinToString(" ") + "}"
                }
            }
        }
    }

    private fun handle(svc: String, ifc: String, method: String, args: List<Any?>) {
        var key = svc + "/" + ifc.removePrefix("Car").removeSuffix("Listener") + "." + method
        val first = args.firstOrNull()
        if (args.size > 1 && first is Int) key += "#" + first
        val text = args.joinToString(", ") { show(it) }
        if (last[key] == text) return
        last[key] = text
        main.post {
            if (values.size < 400 || values.containsKey(key)) values[key] = text
        }
    }
}
