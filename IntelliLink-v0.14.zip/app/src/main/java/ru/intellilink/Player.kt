package ru.intellilink

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.SystemClock
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class NP(
    val access: Boolean = true,
    val controller: MediaController? = null,
    val title: String? = null,
    val artist: String? = null,
    val playing: Boolean = false,
    val art: Bitmap? = null,
    val source: String = "",
    val positionMs: Long = -1,
    val durationMs: Long = 0
)

object Player {
    private var artKey: String? = null
    private var artBmp: Bitmap? = null

    fun loadArt(ctx: Context, md: MediaMetadata?): Bitmap? {
        if (md == null) return null
        md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)?.let { return it }
        md.getBitmap(MediaMetadata.METADATA_KEY_ART)?.let { return it }
        md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)?.let { return it }
        val uri = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
            ?: md.getString(MediaMetadata.METADATA_KEY_ART_URI)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
            ?: return null
        if (uri == artKey) return artBmp
        artKey = uri
        artBmp = try {
            ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) { null }
        return artBmp
    }

    fun read(ctx: Context): NP {
        return try {
            val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
            val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                ?: list.firstOrNull()
            if (c == null) NP() else {
                val md = c.metadata
                val pm = ctx.packageManager
                val label = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(c.packageName, 0)).toString()
                } catch (e: Exception) { c.packageName }
                val ps = c.playbackState
                var pos = ps?.position ?: -1L
                if (ps != null && ps.state == PlaybackState.STATE_PLAYING && ps.lastPositionUpdateTime > 0 && pos >= 0) {
                    pos += ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
                }
                val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
                if (dur > 0 && pos >= 0) pos = pos.coerceIn(0, dur)
                NP(
                    true, c,
                    md?.getString(MediaMetadata.METADATA_KEY_TITLE),
                    md?.getString(MediaMetadata.METADATA_KEY_ARTIST),
                    ps?.state == PlaybackState.STATE_PLAYING,
                    loadArt(ctx, md),
                    label, pos, dur
                )
            }
        } catch (e: SecurityException) {
            NP(access = false)
        } catch (e: Exception) {
            NP()
        }
    }

    fun next(ctx: Context, np: NP) {
        val t = np.controller?.transportControls
        if (t != null) t.skipToNext() else ctx.mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun prev(ctx: Context, np: NP) {
        val t = np.controller?.transportControls
        if (t != null) t.skipToPrevious() else ctx.mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    fun toggle(ctx: Context, np: NP) {
        val t = np.controller?.transportControls
        if (t != null) { if (np.playing) t.pause() else t.play() }
        else ctx.mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
    }
}

object Margins {
    var right by mutableStateOf(40)
    var bottom by mutableStateOf(16)
    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("ui", 0)
        right = p.getInt("mr", 40)
        bottom = p.getInt("mb", 16)
    }
    fun save(ctx: Context) {
        ctx.getSharedPreferences("ui", 0).edit().putInt("mr", right).putInt("mb", bottom).apply()
    }
}

object LinkApp {
    var pkg by mutableStateOf<String?>(null)

    private fun installed(ctx: Context, p: String): Boolean =
        try { ctx.packageManager.getApplicationInfo(p, 0); true } catch (e: Exception) { false }

    fun load(ctx: Context) {
        val saved = ctx.getSharedPreferences("ui", 0).getString("link", null)
        pkg = saved ?: (if (installed(ctx, "com.zjinnova.zlink")) "com.zjinnova.zlink" else null)
    }

    fun save(ctx: Context, p: String) {
        pkg = p
        ctx.getSharedPreferences("ui", 0).edit().putString("link", p).apply()
    }

    fun label(ctx: Context): String {
        val p = pkg ?: return "Выберите приложение"
        return try {
            ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(p, 0)).toString()
        } catch (e: Exception) { "Выберите приложение" }
    }
}
