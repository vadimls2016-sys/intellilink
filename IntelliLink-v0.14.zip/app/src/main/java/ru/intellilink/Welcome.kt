package ru.intellilink

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

const val USER_NAME = "Вадим"

@Composable
fun WelcomeScreen(onOk: () -> Unit) {
    Box(Modifier.fillMaxSize().background(C.bg).tap { }) {
        Image(
            painterResource(R.drawable.welcome_bg), null,
            Modifier.fillMaxSize(), alignment = Alignment.CenterEnd, contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().padding(end = Margins.right.dp, bottom = Margins.bottom.dp)) {
            Column(Modifier.align(Alignment.CenterStart).padding(start = 56.dp)) {
                T("Добро пожаловать,", 36, weight = FontWeight.Medium)
                T(USER_NAME, 72, weight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                Box(Modifier.width(84.dp).height(4.dp).background(C.red))
            }
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp).width(150.dp).height(60.dp)
                    .clip(RoundedCornerShape(14.dp)).background(Color(0xFF45484D)).tap(onOk),
                contentAlignment = Alignment.Center
            ) { T("ОК", 26, weight = FontWeight.Bold) }
        }
    }
}
