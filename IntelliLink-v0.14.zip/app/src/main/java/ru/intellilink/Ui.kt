package ru.intellilink

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object C {
    val bg = Color(0xFF000000)
    val card = Color(0xFF141517)
    val btn = Color(0xFF1E2023)
    val line = Color(0xFF26282B)
    val text = Color(0xFFF2F2F2)
    val dim = Color(0xFFA3A7AC)
    val red = Color(0xFFE2001A)
    val redText = Color(0xFFFF3B4E)
}

enum class Scr(val label: String, val icon: String) {
    HOME("HOME", Ic.HOME), MEDIA("MEDIA", Ic.MEDIA), NAV("NAV", Ic.NAV),
    PHONE("PHONE", Ic.PHONE), CAR("CAR", Ic.CAR), SETTINGS("SETTINGS", Ic.SETTINGS),
    DIAG("DIAG", Ic.SETTINGS), BRIGHT("BRIGHT", Ic.SETTINGS), EQ("EQ", Ic.SETTINGS), CANDIAG("CANDIAG", Ic.SETTINGS), APPS("APPS", Ic.SETTINGS), PICK("PICK", Ic.SETTINGS)
}

// ---------- помощники ----------

fun Modifier.tap(onClick: () -> Unit): Modifier = composed {
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
}

@Composable
fun T(
    text: String, size: Int, color: Color = C.text, weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier, spacing: Float = 0f, align: TextAlign = TextAlign.Unspecified,
    maxLines: Int = Int.MAX_VALUE
) {
    BasicText(
        text, modifier, maxLines = maxLines, overflow = TextOverflow.Ellipsis,
        style = TextStyle(color = color, fontSize = size.sp, fontWeight = weight, letterSpacing = spacing.sp, textAlign = align)
    )
}

fun Context.open(intent: Intent) {
    try {
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(this, "Не удалось открыть", Toast.LENGTH_SHORT).show()
    }
}

fun Context.openPkg(pkg: String) {
    val i = packageManager.getLaunchIntentForPackage(pkg)
    if (i != null) open(i) else Toast.makeText(this, "Не найдено: $pkg", Toast.LENGTH_SHORT).show()
}

fun Context.openNav() {
    val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MAPS)
    open(i)
}

fun Context.mediaKey(code: Int) {
    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
    am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
}

@Composable
fun rememberPlaying(): State<Boolean> {
    val ctx = LocalContext.current
    return produceState(false) {
        while (true) {
            value = (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).isMusicActive
            delay(1000)
        }
    }
}

@Composable
fun rememberNow(): State<Date> = produceState(Date()) {
    while (true) {
        value = Date()
        delay(1000)
    }
}

// ---------- приложение ----------

@Composable
fun App() {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(Scr.HOME) }
    BackHandler(screen != Scr.HOME) {
        screen = when {
            screen == Scr.APPS || screen == Scr.PICK -> Scr.HOME
            screen.ordinal > Scr.SETTINGS.ordinal -> Scr.SETTINGS
            else -> Scr.HOME
        }
    }
    var welcome by remember { mutableStateOf(true) }
    Box(Modifier.fillMaxSize().background(C.bg)) {
    Column(Modifier.fillMaxSize().padding(end = Margins.right.dp)) {
        TopBar { screen = Scr.APPS }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (screen) {
                Scr.HOME -> HomeScreen(onGo = { screen = it })
                Scr.MEDIA -> Box(Modifier.fillMaxSize()) {
                    Image(
                        painterResource(R.drawable.media_bg), null,
                        Modifier.fillMaxSize(), alignment = Alignment.CenterEnd, contentScale = ContentScale.Crop
                    )
                    MediaCard(Modifier.fillMaxHeight().fillMaxWidth(0.44f).padding(16.dp), plain = true)
                }
                Scr.PHONE -> Panel(
                    "PHONE",
                    "Bluetooth-телефон на этой магнитоле обслуживает система. Пока открываем стандартный номеронабиратель.",
                    listOf(
                        "Номеронабиратель" to { ctx.open(Intent(Intent.ACTION_DIAL)) },
                        "Настройки Bluetooth" to { ctx.open(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
                    )
                )
                Scr.CAR -> CarScreen(
                    onInfo = { ctx.openPkg("com.kyhero.car.myhost") },
                    onDiag = { screen = Scr.CANDIAG }
                )
                Scr.SETTINGS -> Panel(
                    "SETTINGS",
                    "Если края экрана обрезаны, увеличьте поля ниже. Эквалайзер будет в следующей версии.",
                    listOf(
                        "Приветствие" to { welcome = true },
                        "Приложение для CarPlay" to { screen = Scr.PICK },
                        "Яркость" to { screen = Scr.BRIGHT },
                        "Эквалайзер" to { screen = Scr.EQ },
                        "Звук Android" to { ctx.open(Intent(Settings.ACTION_SOUND_SETTINGS)) },
                        "Bluetooth" to { ctx.open(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
                        "Все настройки Android" to { ctx.open(Intent(Settings.ACTION_SETTINGS)) },
                        "Лаунчер по умолчанию" to { ctx.open(Intent(Settings.ACTION_HOME_SETTINGS)) },
                        "Диагностика музыки" to { screen = Scr.DIAG },
                        "Диагностика CAN" to { screen = Scr.CANDIAG }
                    )
                ) {
                    MarginRow("Правое поле", Margins.right) { Margins.right = it; Margins.save(ctx) }
                    MarginRow("Нижнее поле", Margins.bottom) { Margins.bottom = it; Margins.save(ctx) }
                }
                Scr.NAV -> {}
                Scr.DIAG -> DiagScreen()
                Scr.BRIGHT -> BrightScreen()
                Scr.EQ -> EqScreen { screen = Scr.APPS }
                Scr.CANDIAG -> CanDiagScreen()
                Scr.APPS -> AppsScreen()
                Scr.PICK -> AppsScreen(onPick = { a ->
                    LinkApp.save(ctx, a.pkg)
                    screen = Scr.HOME
                })
            }
        }
        BottomBar(when {
        screen == Scr.APPS || screen == Scr.PICK -> Scr.HOME
        screen.ordinal > Scr.SETTINGS.ordinal -> Scr.SETTINGS
        else -> screen
    }) { s -> if (s == Scr.NAV) ctx.openNav() else screen = s }
    }
    if (welcome) WelcomeScreen { welcome = false }
    }
}

@Composable
fun TopBar(onApps: () -> Unit) {
    val now by rememberNow()
    val time = SimpleDateFormat("HH:mm", Locale("ru")).format(now)
    val date = SimpleDateFormat("d MMMM, EEE", Locale("ru")).format(now)
    Row(
        Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 28.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Box(Modifier.width(160.dp)) {
            Image(painterResource(R.drawable.opel_logo), "Opel", Modifier.size(48.dp))
        }
        Row(verticalAlignment = Alignment.Bottom) {
            T(time, 32, weight = FontWeight.SemiBold)
            Spacer(Modifier.width(16.dp))
            T(date, 16, color = C.dim, modifier = Modifier.padding(bottom = 4.dp))
        }
        Row(Modifier.width(160.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).tap(onApps), contentAlignment = Alignment.Center) { LineIcon(Ic.APPS, 30.dp, C.dim) }
        }
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(C.line))
}

@Composable
fun BottomBar(current: Scr, onPick: (Scr) -> Unit) {
    Box(Modifier.fillMaxWidth().height(1.dp).background(C.line))
    Row(Modifier.fillMaxWidth().height((88 + Margins.bottom).dp).background(Color(0xFF0A0A0B))) {
        for (s in Scr.values().filter { it.ordinal <= Scr.SETTINGS.ordinal }) {
            val active = s == current
            Column(
                Modifier.weight(1f).fillMaxHeight().tap { onPick(s) }.padding(bottom = Margins.bottom.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.fillMaxWidth().height(3.dp).background(if (active) C.red else Color.Transparent))
                Spacer(Modifier.weight(1f))
                LineIcon(s.icon, 28.dp, if (active) C.redText else C.dim)
                Spacer(Modifier.height(6.dp))
                T(s.label, 13, color = if (active) C.text else C.dim, weight = FontWeight.SemiBold, spacing = 2f)
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

// ---------- экраны ----------

@Composable
fun HomeScreen(onGo: (Scr) -> Unit) {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxSize().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        MediaCard(Modifier.weight(1.35f).fillMaxHeight())
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Tile(Ic.CARPLAY, "CarPlay", LinkApp.label(ctx), Modifier.weight(1f).fillMaxHeight(), iconRes = R.drawable.carplay_logo, onLong = { onGo(Scr.PICK) }) {
                    val lp = LinkApp.pkg
                    if (lp == null) onGo(Scr.PICK) else ctx.openPkg(lp)
                }
                Tile(Ic.PHONE, "Телефон", "Контакты и вызовы", Modifier.weight(1f).fillMaxHeight()) { onGo(Scr.PHONE) }
            }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Tile(Ic.CAR, "Авто", "Данные автомобиля", Modifier.weight(1f).fillMaxHeight()) { onGo(Scr.CAR) }
                Tile(Ic.SETTINGS, "Настройки", "Экран, звук, связь", Modifier.weight(1f).fillMaxHeight()) { onGo(Scr.SETTINGS) }
            }
        }
    }
}

@Composable
fun Tile(icon: String, title: String, sub: String, modifier: Modifier, iconRes: Int? = null, onLong: (() -> Unit)? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.clip(shape).background(C.card).border(1.dp, C.line, shape)
            .pointerInput(onClick, onLong) { detectTapGestures(onTap = { onClick() }, onLongPress = { onLong?.invoke() }) }
            .padding(18.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        if (iconRes != null) Image(painterResource(iconRes), null, Modifier.size(52.dp))
        else LineIcon(icon, 36.dp, C.text, viewBox = 28f)
        Column {
            T(title, 20, weight = FontWeight.SemiBold)
            T(sub, 14, color = C.dim)
        }
    }
}

@Composable
fun MediaCard(modifier: Modifier, plain: Boolean = false) {
    val ctx = LocalContext.current
    val np by produceState(NP()) {
        while (true) {
            value = Player.read(ctx)
            delay(1000)
        }
    }
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.then(if (plain) Modifier else Modifier.clip(shape).background(C.card).border(1.dp, C.line, shape)).padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T("MEDIA", 14, color = C.dim, spacing = 2f)
            T(np.source, 14, color = C.dim)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            val box = RoundedCornerShape(10.dp)
            Box(
                Modifier.size(120.dp).clip(box).background(Color(0xFF0B0B0C)).border(1.dp, Color(0xFF2F3236), box),
                contentAlignment = Alignment.Center
            ) {
                val art = remember(np.art) { np.art?.asImageBitmap() }
                if (art != null) Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else LineIcon(Ic.MEDIA, 48.dp, Color(0xFF6E7378))
            }
            Spacer(Modifier.width(22.dp))
            Column(Modifier.weight(1f)) {
                if (!np.access) {
                    T("Нужен доступ к уведомлениям", 22, weight = FontWeight.SemiBold)
                    Spacer(Modifier.height(10.dp))
                    val sh = RoundedCornerShape(10.dp)
                    Box(
                        Modifier.clip(sh).background(C.red).tap {
                            ctx.open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        }.padding(horizontal = 18.dp, vertical = 12.dp)
                    ) { T("Включить", 16, weight = FontWeight.SemiBold) }
                } else if (np.title == null && np.controller == null) {
                    T("Ничего не играет", 26, weight = FontWeight.SemiBold)
                } else {
                    T(np.title ?: "Без названия", 26, weight = FontWeight.SemiBold, maxLines = 2)
                    Spacer(Modifier.height(6.dp))
                    T(np.artist ?: "", 18, color = C.dim, maxLines = 1)
                }
            }
        }
        Column {
            if (np.durationMs > 0 && np.positionMs >= 0) {
                val f = (np.positionMs.toFloat() / np.durationMs).coerceIn(0f, 1f)
                Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF2A2C2F))) {
                    Box(Modifier.fillMaxWidth(f).fillMaxHeight().background(C.red))
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    T(fmtTime(np.positionMs), 14, color = C.dim)
                    T(fmtTime(np.durationMs), 14, color = C.dim)
                }
                Spacer(Modifier.height(8.dp))
            }
        }
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CtlBtn(Ic.PREV, 76.dp, false) { Player.prev(ctx, np) }
            CtlBtn(if (np.playing) Ic.PAUSE else Ic.PLAY, 96.dp, true) { Player.toggle(ctx, np) }
            CtlBtn(Ic.NEXT, 76.dp, false) { Player.next(ctx, np) }
        }
    }
}

@Composable
fun CtlBtn(icon: String, width: androidx.compose.ui.unit.Dp, accent: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier.width(width).height(64.dp).clip(shape)
            .background(if (accent) C.red else C.btn)
            .border(1.dp, if (accent) C.red else Color(0xFF2F3236), shape)
            .tap(onClick),
        contentAlignment = Alignment.Center
    ) { LineIcon(icon, 28.dp, Color.White, filled = true) }
}

@Composable
fun Panel(title: String, text: String, actions: List<Pair<String, () -> Unit>>, extra: @Composable ColumnScope.() -> Unit = {}) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        T(title, 14, color = C.dim, spacing = 2f)
        T(text, 20, color = C.text)
        Spacer(Modifier.height(8.dp))
        for (row in actions.chunked(2)) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                for ((label, act) in row) {
                    val shape = RoundedCornerShape(12.dp)
                    Box(
                        Modifier.weight(1f).height(64.dp).clip(shape).background(C.card)
                            .border(1.dp, C.line, shape).tap(act),
                        contentAlignment = Alignment.Center
                    ) { T(label, 18, weight = FontWeight.SemiBold) }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        extra()
    }
}

@Composable
fun DiagScreen() {
    val ctx = LocalContext.current
    val sessions by produceState(listOf("…")) {
        while (true) {
            value = Diag.sessions(ctx)
            delay(2000)
        }
    }
    val apps = remember { Diag.apps(ctx) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        T("ДИАГНОСТИКА МУЗЫКИ", 14, color = C.dim, spacing = 2f)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            val shape = RoundedCornerShape(12.dp)
            Box(
                Modifier.height(56.dp).clip(shape).background(C.red).tap {
                    ctx.open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }.padding(horizontal = 20.dp), contentAlignment = Alignment.Center
            ) { T("Включить доступ к уведомлениям", 16, weight = FontWeight.SemiBold) }
        }
        T("Медиа-сессии системы:", 16, weight = FontWeight.SemiBold)
        sessions.forEach { T(it, 14, color = C.dim) }
        T("Сообщения о музыке и Bluetooth (включите музыку по Bluetooth):", 16, weight = FontWeight.SemiBold)
        if (Diag.log.isEmpty()) T("пока ничего не пришло", 14, color = C.dim)
        Diag.log.forEach { T(it, 13, color = C.dim) }
        T("Приложения магнитолы (музыка, Bluetooth, радио):", 16, weight = FontWeight.SemiBold)
        apps.forEach { T(it, 13, color = C.dim) }
    }
}

@Composable
fun MarginRow(label: String, value: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        T(label, 18, modifier = Modifier.width(200.dp))
        StepBtn("−") { onChange((value - 8).coerceAtLeast(0)) }
        T("$value", 20, weight = FontWeight.SemiBold, modifier = Modifier.width(56.dp), align = TextAlign.Center)
        StepBtn("+") { onChange((value + 8).coerceAtMost(200)) }
    }
}

@Composable
fun StepBtn(s: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier.size(56.dp).clip(shape).background(C.btn).border(1.dp, C.line, shape).tap(onClick),
        contentAlignment = Alignment.Center
    ) { T(s, 26, weight = FontWeight.Bold) }
}
