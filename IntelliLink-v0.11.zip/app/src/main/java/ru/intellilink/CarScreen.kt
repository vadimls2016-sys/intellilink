package ru.intellilink

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

private fun f1(v: Float?): String = if (v == null) "—" else String.format(Locale.US, "%.1f", v)
private fun f0(v: Float?): String = if (v == null) "—" else String.format(Locale.US, "%.0f", v)
private fun i0(v: Int?): String = if (v == null) "—" else v.toString()

@Composable
fun Flag(label: String, on: Boolean?, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(10.dp)
    val bg = when (on) {
        true -> C.red
        false -> C.btn
        null -> C.card
    }
    Box(
        modifier.height(48.dp).clip(shape).background(bg).border(1.dp, if (on == true) C.red else C.line, shape),
        contentAlignment = Alignment.Center
    ) {
        T(label, 15, color = if (on == null) C.dim else C.text, weight = FontWeight.SemiBold)
    }
}

@Composable
fun InfoCard(title: String, modifier: Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.clip(shape).background(C.card).border(1.dp, C.line, shape).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        T(title, 14, color = C.dim, spacing = 2f)
        content()
    }
}

@Composable
fun CarScreen(onInfo: () -> Unit, onDiag: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (!CarState.any()) {
            T("Данные появятся, когда автомобиль их пришлёт: нажмите кнопку климата или откройте дверь.", 15, color = C.dim)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            InfoCard("КЛИМАТ", Modifier.weight(1.2f)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        T("Слева", 14, color = C.dim)
                        T(f1(CarState.leftTemp), 44, weight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        T("Справа", 14, color = C.dim)
                        T(f1(CarState.rightTemp), 44, weight = FontWeight.Bold)
                    }
                }
                T(
                    "Вентилятор: " + i0(CarState.fan) + "   Режим: " + i0(CarState.mode) + "   Циркуляция: " + i0(CarState.cycle),
                    16, color = C.dim
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Flag("A/C", CarState.ac, Modifier.weight(1f))
                    Flag("Лобовое", CarState.frontDefrost, Modifier.weight(1f))
                    Flag("Заднее", CarState.rearDefrost, Modifier.weight(1f))
                    Flag("PTC", CarState.ptc, Modifier.weight(1f))
                }
                Flag("Климат включён", CarState.power, Modifier.fillMaxWidth())
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                InfoCard("ДВЕРИ (красным: открыто)", Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Flag("Л-перед", CarState.lf, Modifier.weight(1f))
                        Flag("Пр-перед", CarState.rf, Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Flag("Л-зад", CarState.lr, Modifier.weight(1f))
                        Flag("Пр-зад", CarState.rr, Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Flag("Капот", CarState.hood, Modifier.weight(1f))
                        Flag("Багажник", CarState.trunk, Modifier.weight(1f))
                    }
                }
                InfoCard("ДВИЖЕНИЕ", Modifier.fillMaxWidth()) {
                    T("Передача: " + i0(CarState.gear), 20, weight = FontWeight.SemiBold)
                    T("Скорость: " + f0(CarState.speed) + " км/ч   Средняя: " + f0(CarState.avgSpeed), 17)
                    T("Запас хода: " + f0(CarState.range), 17, color = C.dim)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Chip("Штатное «Инфо авто»") { onInfo() }
            Chip("Диагностика CAN") { onDiag() }
        }
    }
}
