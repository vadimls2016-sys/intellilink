package ru.intellilink

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp

object Ic {
    const val LOGO = "M3 15a12 12 0 1 0 24 0a12 12 0 1 0 -24 0M5 15h20M17 8l-5 7h6l-5 7"
    const val HOME = "M4 14L14 5l10 9M7 12v11h14V12"
    const val MEDIA = "M10 21V6l13-3v15M4 21a3 3 0 1 0 6 0a3 3 0 1 0 -6 0M17 18a3 3 0 1 0 6 0a3 3 0 1 0 -6 0"
    const val NAV = "M14 3l9 21-9-5-9 5z"
    const val PHONE = "M7 3h5l2 6-3 2a12 12 0 0 0 6 6l2-3 6 2v5a2 2 0 0 1-2 2A19 19 0 0 1 5 5a2 2 0 0 1 2-2z"
    const val CAR = "M4 17l2-7a2 2 0 0 1 2-1h12a2 2 0 0 1 2 1l2 7v5H4zM8 18a1 1 0 1 0 2 0a1 1 0 1 0 -2 0M18 18a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"
    const val SETTINGS = "M4 9h11M21 9h3M4 19h3M13 19h11M15 9a3 3 0 1 0 6 0a3 3 0 1 0 -6 0M7 19a3 3 0 1 0 6 0a3 3 0 1 0 -6 0"
    const val PREV = "M6 5h3v18H6zM24 5v18L11 14z"
    const val NEXT = "M19 5h3v18h-3zM4 5v18l13-9z"
    const val PAUSE = "M7 5h5v18H7zM16 5h5v18h-5z"
    const val PLAY = "M8 5v18l16-9z"
}

@Composable
fun LineIcon(path: String, size: Dp, color: Color, filled: Boolean = false, viewBox: Float = 28f) {
    val p = remember(path) { PathParser().parsePathString(path).toPath() }
    Canvas(Modifier.size(size)) {
        val s = this.size.width / viewBox
        scale(s, s, pivot = Offset.Zero) {
            if (filled) {
                drawPath(p, color)
            } else {
                drawPath(p, color, style = Stroke(width = 2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}
