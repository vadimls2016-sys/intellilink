package ru.intellilink

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Diag.start(this)
        setContent { App() }
    }

    override fun onDestroy() {
        Diag.stop(this)
        super.onDestroy()
    }
}
