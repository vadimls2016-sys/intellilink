package ru.intellilink

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Parcel
import android.os.Parcelable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import java.lang.reflect.Proxy
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

// Только слушаем данные CAN у штатного приложения магнитолы. Ничего в автомобиль не отправляем.
object CanLink {
    private const val PKG = "com.kyhero.car.myhost"
    val values = mutableStateMapOf<String, String>()
    val methods = mutableStateListOf<String>()
    val changes = mutableStateListOf<String>()
    val fresh = mutableStateMapOf<String, Long>()
    private val history = ConcurrentHashMap<String, ArrayList<Long>>()
    private val main = Handler(Looper.getMainLooper())
    private val keep = ArrayList<Any>()
    private val last = ConcurrentHashMap<String, String>()
    private var started = false

    private val targets = listOf(
        Triple("Data", "com.kyhero.car.myhost.Canset.AidlToOutDataService", "com.kyhero.car.myhost.action"),
        Triple("Data6115", "com.kyhero.car.myhost.Canset.AidlToOutData6115Service", "com.kyhero.car.myhost.action1"),
        Triple("Bus", "com.kyhero.car.myhost.Canset.CanbusService", "com.xygala.buslibrary.IBusService")
    )

    fun start(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        for (t in targets) {
            val short = t.first
            val conn = object : ServiceConnection {
                override fun onServiceConnected(n: ComponentName, b: IBinder) {
                    Thread { attach(app, short, b) }.start()
                }
                override fun onServiceDisconnected(n: ComponentName) {
                    Diag.addUi("CAN $short: служба отключилась")
                }
            }
            synchronized(keep) { keep.add(conn) }
            try {
                app.bindService(Intent(t.third).setClassName(PKG, t.second), conn, Context.BIND_AUTO_CREATE)
            } catch (e: Exception) {
                Diag.addUi("CAN $short: ${e.message}")
            }
        }
    }

    private fun attach(ctx: Context, short: String, b: IBinder) {
        try {
            val desc: String = try { b.interfaceDescriptor ?: "" } catch (e: Exception) { "" }
            val path = ctx.packageManager.getApplicationInfo(PKG, 0).sourceDir
            val cl = dalvik.system.PathClassLoader(path, null, ctx.classLoader)
            val iface = cl.loadClass(desc)
            val stub = cl.loadClass(desc + "\$Stub")
            val proxy = stub.getMethod("asInterface", IBinder::class.java).invoke(null, b)
            val reg = iface.declaredMethods.firstOrNull { it.name == "registerListener" || it.name == "registerCallback" }
            if (reg == null) {
                Diag.addUi("CAN $short: нет метода подписки")
                return
            }
            val params = reg.parameterTypes
            val args = arrayOfNulls<Any>(params.size)
            for (i in params.indices) args[i] = makeListener(params[i], short)
            reg.invoke(proxy, *args)
            Diag.addUi("CAN $short: подписка оформлена, слушателей: ${params.size}")
        } catch (e: Throwable) {
            val c = e.cause ?: e
            Diag.addUi("CAN $short: ошибка подписки ${c.javaClass.simpleName} ${c.message}")
        }
    }

    private fun makeListener(cls: Class<*>, svc: String): Any {
        val loader = cls.classLoader
        val stubCls: Class<*>? = try { loader.loadClass(cls.name + "\$Stub") } catch (e: Throwable) { null }
        var desc = cls.name
        if (stubCls != null) {
            try {
                val f = stubCls.getDeclaredField("DESCRIPTOR")
                f.isAccessible = true
                desc = f.get(null) as String
            } catch (e: Throwable) { }
        }
        val finalDesc = desc
        val ifcName = cls.simpleName
        val codes = HashMap<Int, Method>()
        val sigs = ArrayList<String>()
        for (m in cls.declaredMethods) {
            sigs.add(svc + " " + ifcName + "." + m.name + "(" + m.parameterTypes.joinToString { it.simpleName } + ")")
            if (stubCls != null) {
                try {
                    val f = stubCls.getDeclaredField("TRANSACTION_" + m.name)
                    f.isAccessible = true
                    codes[f.getInt(null)] = m
                } catch (e: Throwable) { }
            }
        }
        main.post { methods.addAll(sigs) }

        val binder = object : Binder() {
            init {
                attachInterface(null, finalDesc)
            }

            override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
                val m = codes[code] ?: return super.onTransact(code, data, reply, flags)
                try {
                    data.enforceInterface(finalDesc)
                    val vals = ArrayList<Any?>()
                    for (t in m.parameterTypes) vals.add(readArg(data, t))
                    handle(svc, ifcName, m.name, vals)
                } catch (e: Throwable) {
                    if (last.put("err:" + ifcName + "." + m.name, "1") == null) {
                        Diag.addUi("CAN: не разобран вызов $ifcName.${m.name}: ${e.message}")
                    }
                }
                if (reply != null) {
                    reply.writeNoException()
                    val rt = m.returnType
                    if (rt == java.lang.Integer.TYPE || rt == java.lang.Boolean.TYPE) reply.writeInt(0)
                    else if (rt == java.lang.Float.TYPE) reply.writeFloat(0f)
                }
                return true
            }
        }

        val handler = InvocationHandler { _, method, _ ->
            when (method.name) {
                "asBinder" -> binder
                "hashCode" -> System.identityHashCode(binder)
                "equals" -> false
                "toString" -> "CanListener"
                else -> null
            }
        }
        val obj = Proxy.newProxyInstance(loader, arrayOf(cls), handler)
        synchronized(keep) {
            keep.add(binder)
            keep.add(obj)
        }
        return obj
    }

    private fun readArg(d: Parcel, t: Class<*>): Any? {
        if (t == java.lang.Integer.TYPE) return d.readInt()
        if (t == java.lang.Float.TYPE) return d.readFloat()
        if (t == java.lang.Double.TYPE) return d.readDouble()
        if (t == java.lang.Long.TYPE) return d.readLong()
        if (t == java.lang.Boolean.TYPE) return d.readInt() != 0
        if (t == java.lang.Byte.TYPE) return d.readByte()
        if (t == String::class.java) return d.readString()
        if (t == IntArray::class.java) return d.createIntArray()
        if (t == ByteArray::class.java) return d.createByteArray()
        if (t == FloatArray::class.java) return d.createFloatArray()
        if (t == DoubleArray::class.java) return d.createDoubleArray()
        if (t == LongArray::class.java) return d.createLongArray()
        if (t == BooleanArray::class.java) return d.createBooleanArray()
        if (t == Array<String>::class.java) return d.createStringArray()
        val creator = try { t.getField("CREATOR").get(null) } catch (e: Throwable) { null }
        if (creator is Parcelable.Creator<*>) {
            return if (d.readInt() != 0) creator.createFromParcel(d) else null
        }
        throw IllegalStateException("тип " + t.name)
    }

    private fun show(o: Any?, depth: Int = 0): String {
        if (o == null) return "null"
        return when (o) {
            is ByteArray -> o.take(32).joinToString(" ") { String.format("%02X", it) } + (if (o.size > 32) "…" else "")
            is IntArray -> o.joinToString(",")
            is FloatArray -> o.joinToString(",")
            is DoubleArray -> o.joinToString(",")
            is LongArray -> o.joinToString(",")
            is BooleanArray -> o.joinToString(",")
            is Array<*> -> o.joinToString(",") { show(it, depth + 1) }
            is String, is Number, is Boolean -> o.toString()
            else -> {
                if (depth >= 2) {
                    o.toString().take(40)
                } else {
                    val parts = ArrayList<String>()
                    for (f in o.javaClass.declaredFields) {
                        if (Modifier.isStatic(f.modifiers)) continue
                        try {
                            f.isAccessible = true
                            parts.add(f.name + "=" + show(f.get(o), depth + 1))
                        } catch (e: Throwable) { }
                    }
                    if (parts.isEmpty()) o.toString().take(60) else "{" + parts.joinToString(" ") + "}"
                }
            }
        }
    }

    private fun handle(svc: String, ifc: String, method: String, args: List<Any?>) {
        val first = args.firstOrNull()
        if (method == "onDataReceived" && first is ByteArray) {
            handleRaw(first)
            return
        }
        var key = svc + "/" + ifc.removePrefix("Car").removeSuffix("Listener") + "." + method
        if (args.size > 1 && first is Int) key += "#" + first
        val k = key
        val text = args.joinToString(", ") { show(it) }
        if (last[k] == text) return
        last[k] = text
        main.post {
            if (values.size < 400 || values.containsKey(k)) values[k] = text
            applyState(method, args)
        }
    }

    // Сырые кадры шины Raise: 2E, тип, длина, данные..., контрольная сумма. Храним последнее значение каждого типа.
    private fun handleRaw(b: ByteArray) {
        val key: String
        val text: String
        if (b.size >= 4 && (b[0].toInt() and 0xFF) == 0x2E) {
            val type = b[1].toInt() and 0xFF
            val len = b[2].toInt() and 0xFF
            val end = minOf(3 + len, b.size)
            val payload = b.copyOfRange(3, end)
            key = "Bus/кадр " + String.format("%02X", type)
            text = payload.joinToString(" ") { String.format("%02X", it) }
        } else {
            key = "Bus/прочее"
            text = b.take(32).joinToString(" ") { String.format("%02X", it) }
        }
        val old = last[key]
        if (old == text) return
        last[key] = text
        val now = System.currentTimeMillis()
        val hist = history.getOrPut(key) { ArrayList() }
        val noisy = synchronized(hist) {
            hist.add(now)
            while (hist.isNotEmpty() && now - hist[0] > 10000L) hist.removeAt(0)
            hist.size > 8
        }
        val line = if (old == null) text else text + "  (было " + old + ")"
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(now))
        main.post {
            if (values.size < 400 || values.containsKey(key)) values[key] = line
            fresh[key] = now
            if (!noisy && old != null) {
                changes.add(0, stamp + " " + key.removePrefix("Bus/") + ": " + old + " → " + text)
                while (changes.size > 60) changes.removeAt(changes.size - 1)
            }
        }
    }

    private fun applyState(m: String, a: List<Any?>) {
        val v = a.firstOrNull()
        when (m) {
            "onAirLeftTempeChanged" -> CarState.leftTemp = v as? Float
            "onAirRightTempeChanged" -> CarState.rightTemp = v as? Float
            "onAirWindSpeedChanged" -> CarState.fan = v as? Int
            "onAirWindModeChanged" -> CarState.mode = v as? Int
            "onAirCycleChanged" -> CarState.cycle = v as? Int
            "onAirAcChanged" -> CarState.ac = v as? Boolean
            "onAirFrontDefrostChanged" -> CarState.frontDefrost = v as? Boolean
            "onAirRearDefrostChanged" -> CarState.rearDefrost = v as? Boolean
            "onAirPTCChanged" -> CarState.ptc = v as? Boolean
            "onAirSwitchChanged" -> CarState.power = v as? Boolean
            "onDoorHoodChanged" -> CarState.hood = v as? Boolean
            "onDoorLeftFrontChanged" -> CarState.lf = v as? Boolean
            "onDoorLeftRearChanged" -> CarState.lr = v as? Boolean
            "onDoorRightFrontChanged" -> CarState.rf = v as? Boolean
            "onDoorRightRearChanged" -> CarState.rr = v as? Boolean
            "onDoorTrunkChanged" -> CarState.trunk = v as? Boolean
            "onGearChanged" -> CarState.gear = v as? Int
            "onCarMomentarySpeed" -> CarState.speed = v as? Float
            "onCarAverageSpeed" -> CarState.avgSpeed = v as? Float
            "onCruisingRangeValue" -> CarState.range = v as? Float
        }
    }
}

object CarState {
    var leftTemp by mutableStateOf<Float?>(null)
    var rightTemp by mutableStateOf<Float?>(null)
    var fan by mutableStateOf<Int?>(null)
    var mode by mutableStateOf<Int?>(null)
    var cycle by mutableStateOf<Int?>(null)
    var ac by mutableStateOf<Boolean?>(null)
    var frontDefrost by mutableStateOf<Boolean?>(null)
    var rearDefrost by mutableStateOf<Boolean?>(null)
    var ptc by mutableStateOf<Boolean?>(null)
    var power by mutableStateOf<Boolean?>(null)
    var hood by mutableStateOf<Boolean?>(null)
    var lf by mutableStateOf<Boolean?>(null)
    var lr by mutableStateOf<Boolean?>(null)
    var rf by mutableStateOf<Boolean?>(null)
    var rr by mutableStateOf<Boolean?>(null)
    var trunk by mutableStateOf<Boolean?>(null)
    var gear by mutableStateOf<Int?>(null)
    var speed by mutableStateOf<Float?>(null)
    var avgSpeed by mutableStateOf<Float?>(null)
    var range by mutableStateOf<Float?>(null)

    fun any(): Boolean = leftTemp != null || rightTemp != null || fan != null || lf != null || rf != null || gear != null || speed != null
}
